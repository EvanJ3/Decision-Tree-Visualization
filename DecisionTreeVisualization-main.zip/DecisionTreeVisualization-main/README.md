# DecisionTreeVisualization

This script can be used to write Sklearn decision trees using Graphviz and Pydot to an interactively pan/zoomable webpage for easy and self contained exploration and sharing.

![image](https://user-images.githubusercontent.com/107420342/209373465-8d2a08e8-723c-4b94-91ff-b789d1fa5c75.png)
